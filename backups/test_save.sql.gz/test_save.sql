--
-- PostgreSQL database dump
--

\restrict AMA7TUtDhRz07cB3cYlRIenJVXOaYdhpA3ahR5K5bXJeqiSdeLdJIAYp3A9SWbo

-- Dumped from database version 16.13 (Debian 16.13-1.pgdg13+1)
-- Dumped by pg_dump version 16.13 (Debian 16.13-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: daily_briefings; Type: TABLE; Schema: public; Owner: huduser
--

CREATE TABLE public.daily_briefings (
    id bigint NOT NULL,
    briefing_date date,
    category character varying(255),
    markdown_content text,
    generated_at timestamp(6) without time zone,
    model_name character varying(255)
);


ALTER TABLE public.daily_briefings OWNER TO huduser;

--
-- Name: daily_briefings_id_seq; Type: SEQUENCE; Schema: public; Owner: huduser
--

CREATE SEQUENCE public.daily_briefings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.daily_briefings_id_seq OWNER TO huduser;

--
-- Name: daily_briefings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: huduser
--

ALTER SEQUENCE public.daily_briefings_id_seq OWNED BY public.daily_briefings.id;


--
-- Name: llm_configs; Type: TABLE; Schema: public; Owner: huduser
--

CREATE TABLE public.llm_configs (
    id bigint NOT NULL,
    active boolean NOT NULL,
    api_key character varying(255),
    base_url character varying(255),
    model_name character varying(255),
    name character varying(255) NOT NULL,
    num_ctx integer,
    provider character varying(255) NOT NULL,
    updated_at timestamp(6) without time zone,
    CONSTRAINT llm_configs_provider_check CHECK (((provider)::text = ANY ((ARRAY['OLLAMA'::character varying, 'GEMINI'::character varying])::text[])))
);


ALTER TABLE public.llm_configs OWNER TO huduser;

--
-- Name: llm_configs_id_seq; Type: SEQUENCE; Schema: public; Owner: huduser
--

CREATE SEQUENCE public.llm_configs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.llm_configs_id_seq OWNER TO huduser;

--
-- Name: llm_configs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: huduser
--

ALTER SEQUENCE public.llm_configs_id_seq OWNED BY public.llm_configs.id;


--
-- Name: pipeline_runs; Type: TABLE; Schema: public; Owner: huduser
--

CREATE TABLE public.pipeline_runs (
    id bigint NOT NULL,
    category character varying(255),
    end_time timestamp(6) without time zone,
    error_message text,
    start_time timestamp(6) without time zone,
    status character varying(255),
    model_name character varying(255),
    CONSTRAINT pipeline_runs_status_check CHECK (((status)::text = ANY ((ARRAY['PENDING'::character varying, 'SUCCESS'::character varying, 'FAILED'::character varying])::text[])))
);


ALTER TABLE public.pipeline_runs OWNER TO huduser;

--
-- Name: pipeline_runs_id_seq; Type: SEQUENCE; Schema: public; Owner: huduser
--

CREATE SEQUENCE public.pipeline_runs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.pipeline_runs_id_seq OWNER TO huduser;

--
-- Name: pipeline_runs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: huduser
--

ALTER SEQUENCE public.pipeline_runs_id_seq OWNED BY public.pipeline_runs.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: huduser
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    password character varying(255) NOT NULL,
    role character varying(255) NOT NULL,
    username character varying(255) NOT NULL
);


ALTER TABLE public.users OWNER TO huduser;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: huduser
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO huduser;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: huduser
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: daily_briefings id; Type: DEFAULT; Schema: public; Owner: huduser
--

ALTER TABLE ONLY public.daily_briefings ALTER COLUMN id SET DEFAULT nextval('public.daily_briefings_id_seq'::regclass);


--
-- Name: llm_configs id; Type: DEFAULT; Schema: public; Owner: huduser
--

ALTER TABLE ONLY public.llm_configs ALTER COLUMN id SET DEFAULT nextval('public.llm_configs_id_seq'::regclass);


--
-- Name: pipeline_runs id; Type: DEFAULT; Schema: public; Owner: huduser
--

ALTER TABLE ONLY public.pipeline_runs ALTER COLUMN id SET DEFAULT nextval('public.pipeline_runs_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: huduser
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: daily_briefings; Type: TABLE DATA; Schema: public; Owner: huduser
--

COPY public.daily_briefings (id, briefing_date, category, markdown_content, generated_at, model_name) FROM stdin;
82	\N	WORLD_NEWS	## Geopolitical Strategy Report: Deterrence Erosion and Maritime Flashpoints\n\nThe transatlantic security architecture is undergoing significant stress due to perceived shifts in US commitment. Germany's Defence Minister, Boris Pistorius, characterizing the planned US withdrawal of troops as "foreseeable," highlights growing concerns within NATO regarding the reliability of American deterrence. This move, coupled with calls from Polish officials for a reversal of the "disastrous trend," signals a potential pivot toward greater European self-reliance. While Germany is accelerating its defense spending, the withdrawal underscores a structural challenge to the alliance, forcing member states to assume greater responsibility for shared security while simultaneously navigating the political volatility of US foreign policy.\n\nInternational friction points are acutely concentrated in the Middle East, driven by escalating conflict and contested maritime choke points. The ongoing fighting between Israel and Iran-backed Hezbollah in Lebanon, despite ceasefire efforts, continues to generate casualties and instability. Concurrently, the US has maintained a naval blockade on Iranian ports and threatened sanctions against shipping firms paying tolls in the Strait of Hormuz. Iran's collection of tolls and the sharp decline in vessel traffic through the strait transform a critical global oil artery into a high-risk geopolitical flashpoint, directly impacting global supply chains and humanitarian aid delivery.\n\nThe confluence of these regional tensions and unpredictable US policy creates a volatile macro-stability environment. President Trump's public skepticism regarding potential peace deals with Iran, coupled with his assertion that a ceasefire negates the need for Congressional war authorization, introduces significant legal and strategic uncertainty. Furthermore, the US continues to employ targeted sanctions, exemplified by the actions against Iranian financial institutions, demonstrating a sustained effort to restrict the regime's revenue generation. These actions, combined with the humanitarian crisis in Gaza—where displaced populations face severe health risks—underscore the persistent and deepening instability across the region.	2026-05-02 18:01:51.833593	Local Gemma
83	\N	US_NEWS	### Domestic Policy Briefing: Internal Strategic Landscape Assessment\n\nThe domestic policy environment is characterized by significant legal and political friction, creating instability across key sectors. Legislative shifts are most acutely visible in reproductive healthcare, where court action has severely curtailed access to mifepristone, establishing a restrictive precedent for medication abortion. Furthermore, the ongoing debate surrounding the War Powers Act highlights a deep constitutional rift between the executive branch and Congress, with the administration attempting to redefine the parameters of military engagement to bypass traditional legislative oversight. This conflict not only threatens the established checks and balances but also signals a willingness to challenge foundational legal norms in the name of executive action.\n\nEconomically, the nation faces mounting pressure from volatile energy prices, exacerbated by geopolitical instability and the effective closure of critical shipping lanes like the Strait of Hormuz. This volatility directly impacts consumer costs, contributing to public discontent, as evidenced by public reactions to rising gas prices. The failure of bailout talks for major carriers, such as Spirit Airlines, underscores a growing skepticism regarding federal intervention in private industry, suggesting a tightening of the economic safety net and increasing market vulnerability.\n\nDomestic stability remains highly polarized and volatile. Political dissent is manifesting through large-scale protests, such as the May Day demonstrations, which reflect deep-seated demands for social and economic justice. Simultaneously, the political sphere is becoming increasingly personalized and contentious, visible in the heightened political activity within communities like Florida's retirement villages. These events illustrate a trend where political identity is deeply interwoven with personal life and community structure, making local governance and social cohesion increasingly difficult to manage. Finally, the rapid integration of Artificial Intelligence into public life—from autonomous vehicle regulation in California to new eligibility rules for film awards—requires immediate, coordinated federal policy development to prevent regulatory gaps and ensure consumer protection.	2026-05-02 18:02:14.275327	Local Gemma
84	\N	FINANCE	## Macro Assessment: Market Health and Systemic Financial Risk\n\nMarket volatility remains elevated, driven by a bifurcated focus between corporate earnings momentum and acute geopolitical uncertainty. While investor sentiment is currently anchored by positive earnings reports from major technology firms, the underlying market structure is highly sensitive to external shocks. The recent volatility surrounding the Middle East—ranging from blockade threats to ceasefire agreements—demonstrates that geopolitical risk remains a primary driver of short-term price action, overshadowing fundamental economic metrics. Furthermore, the sharp spike in commodity costs, exemplified by jet fuel prices, is creating systemic stress across capital-intensive sectors, suggesting that cost inflation is rapidly translating into operational insolvency for non-essential industries.\n\nFiscal policy is exhibiting signs of increasing instability and unpredictable intervention. The collapse of the Spirit Airlines bailout talks highlights the limits of government support when faced with sustained, structural cost pressures, particularly those related to energy inputs. Simultaneously, the escalation of trade tensions, specifically the threat of increased tariffs on EU automotive imports, signals a sharp deterioration in predictable transatlantic trade relationships. This policy volatility introduces significant supply chain risk and raises the cost of capital for international commerce, undermining the stability provided by previous trade agreements.\n\nSystemic risk is manifesting through the failure of key institutional pillars and the widening gap between policy rhetoric and execution. The abrupt demise of the budget airline, driven by fuel costs and the failure of a rescue deal, serves as a stark indicator of sector fragility. On a macro level, the aggressive and arbitrary nature of tariff hikes, coupled with the EU's stated intent to "keep options open," suggests a return to protectionist trade cycles. This combination of unpredictable fiscal policy and sector-specific insolvency points to a heightened risk environment where corporate resilience is severely tested by both energy inflation and geopolitical friction.	2026-05-02 18:02:37.818641	Local Gemma
85	\N	TECHNOLOGY	### TACTICAL BRIEFING:\n\nThe current landscape reveals critical vulnerabilities in the foundational layers of AI-driven decision-making, specifically concerning self-preferencing bias and data integrity. Empirical evidence demonstrates that Large Language Models (LLMs) exhibit a systemic bias, favoring content generated by their own architecture over human-written or alternative model outputs, with self-preference bias ranging from 67% to 82% in simulated hiring pipelines. This bias represents a significant, overlooked risk in AI-assisted decision systems, suggesting that the very tools designed to optimize human capital are introducing a non-transparent, algorithmic moat that disadvantages human-centric inputs. Furthermore, the convergence of LLMs with public knowledge repositories like Wikipedia creates a potent vector for information warfare, where state-sponsored actors are actively poisoning training data and rewriting historical narratives to align with geopolitical objectives.\n\nInfrastructure robustness is under direct assault from sophisticated, transnational disinformation campaigns. The systematic manipulation of platforms like Wikipedia, utilizing coordinated networks and sanctioned news outlets, demonstrates a targeted effort to corrupt the "sum of all human knowledge." This threat is amplified by the fact that LLMs increasingly rely on these compromised sources, effectively laundering malicious narratives into the core of global AI intelligence. Simultaneously, the surveillance infrastructure remains highly porous; from corporate data collection in vehicles to the use of License Plate Readers for non-security purposes, the expansion of digital monitoring represents a critical erosion of privacy and autonomy.\n\nFrom a technical moat perspective, the battleground is shifting toward open-source resilience and specialized, decentralized tooling. The continued emphasis on open protocols (e.g., OpenWarp) and the advocacy for open-source code in critical public infrastructure (NHS) signal a necessary counter-movement against proprietary, opaque systems. Concurrently, the emergence of advanced, cost-effective frontier models (e.g., DeepSeek V4) suggests a rapid democratization of high-level AI capability, potentially disrupting the current oligopoly of major AI providers. The focus on specialized data tooling, such as full-text search integration with databases like DuckDB, highlights a technical trend toward optimizing data retrieval and processing at the edge, bypassing reliance on monolithic, centralized cloud services.	2026-05-02 18:03:03.670412	Local Gemma
86	\N	GLOBAL_SITREP	The operational environment remains characterized by a strategic stalemate across all major axes, with neither side achieving confirmed breakthroughs. However, the strategic balance is being heavily influenced by sustained, deep-strike campaigns targeting critical Russian infrastructure and military assets. The focus of these efforts has been the systematic degradation of Russia’s energy sector, with repeated, high-impact strikes against major oil refineries in regions including Krasnodar, Perm, and Orenburg. This sustained pressure has significantly degraded the average output of Russian oil refineries, pushing output to levels not seen since late 2009. Concurrently, the campaign has extended deep into Russian territory, targeting airfields and military installations hundreds of kilometers from the front lines, severely disrupting Russian air power and logistical capabilities.\n\nOn the ground, fighting remains intensely localized and focused on attrition rather than maneuver. Across the Eastern and Southern fronts, Russian forces continue to employ infiltration missions, often utilizing pipelines to penetrate Ukrainian defensive lines. Ukrainian forces are countering these efforts with coordinated counterattacks, increasingly relying on unmanned aerial and ground vehicles to eliminate personnel and assets. In the Donetsk and Slovyansk sectors, while Russian forces attempt to increase the tempo and size of ground assaults to compensate for difficulties penetrating dense frontline air defenses, the effectiveness of these efforts is diminishing.\n\nThe tactical nature of the combat has shifted toward highly granular, low-intensity engagements. In areas like Oleksandrivka and Pokrovsk, Russian ground assaults are reportedly decreasing in size, often consisting of single infantrymen. While these small-scale attacks are proving somewhat effective at penetrating defenses, they are being countered by sophisticated Ukrainian drone operations. Furthermore, the operational tempo remains exceptionally high, particularly in the Kramatorsk direction, where Russian forces maintain a high volume of artillery and drone strikes, while simultaneously increasing the use of advanced reconnaissance and "sleeper" drone technology.\n\nOverall, the theater is defined by a complex interplay between strategic economic warfare in the rear and brutal, localized attrition combat on the front. The strategic pressure exerted on Russian energy and military infrastructure continues to mount, while the frontline remains locked in a cycle of infiltration attempts and counter-strikes. The operational focus for both sides is now centered on maintaining defensive positions and maximizing localized combat effectiveness through advanced, unmanned systems.	2026-05-02 18:03:36.029224	Local Gemma
87	\N	THEATER_UKRAINE	# UKRAINE THEATER REPORT\n\n## Tactical Momentum\nUkrainian forces maintained a high operational tempo through sustained, deep-strike campaigns targeting critical Russian infrastructure. Between April 29 and May 1, strikes were executed against major oil assets, including the Tuapse Oil Refinery in Krasnodar Krai, which was hit for the fourth time since April 1, and the Permsky Oil Refinery in Perm Krai. These sustained attacks have degraded the average output of Russian oil refineries to their lowest level since December 2009. Furthermore, Ukrainian forces conducted significant strikes against Russian military assets far from the frontline, including the elimination of Su-57 and Su-34 fighter jets at the Shagol Airfield in Chelyabinsk Oblast, and the targeting of radar and drone warehouses in Belgorod Oblast. These long-range strikes, alongside attacks on airfields and military depots, indicate a continued strategic effort to degrade Russia's industrial and military capacity.\n\nOn the ground, combat operations remained fluid, characterized by localized offensives and persistent infiltration attempts. In the Kharkiv and Kupyansk directions, Russian forces continued using pipelines for small-group infiltration missions, though Ukrainian forces reportedly counterattacked in Kupyansk. In Donetsk Oblast, Russian forces increased the tempo of infantry attacks in response to difficulties penetrating Ukrainian air defenses, while Ukrainian forces continued to strike Russian positions in the Slovyansk and Kostyantynivka directions. Near Pokrovsk, Russian airborne elements attempted advances, but these were countered by Ukrainian strikes. Overall, while Russian forces continued limited offensive operations in multiple sectors, including Novopavlivka and Oleksandrivka, confirmed advances were minimal, with the fighting remaining focused on attrition and localized tactical gains.\n\n## Kinetic Impact\n\n| Target | Location | Distance |\n| :--- | :--- | :--- |\n| Tuapse Oil Refinery | Krasnodar Krai | N/A |\n| Permsky Oil Refinery | Perm Krai | N/A |\n| Orsknefteorgsintez Oil Refinery | Orenburg Oblast | N/A |\n| Su-57 fighter jets and Su-34 fighter-bombers | Shagol Airfield, Chelyabinsk Oblast | Approx. 1,676 km from international border |\n| Mi-28 and Mi-17 helicopters | Near Babky, Voronezh Oblast | Roughly 150 km from the frontline |\n| Russian drone warehouse | Near Dalny, Belgorod Oblast | Just on the international border |\n| Russian Nebo-M radar | Ukolovo, Belgorod Oblast | Roughly 110 km from the international border |\n| Russian artillery brigade command post | Occupied Lysychansk | Roughly 35 km from the frontline |\n| Russian ammunition depot | Near Rovenky | Roughly 125 km from the frontline |\n| Russian position | Central Yampil, northeast of Slovyansk | N/A |\n| Russian positions | Northern Berestok and southeastern Kostyantynivka | N/A |\n| Elements of the Russian 76th VDV Division | Central Hryshyne, northwest of Pokrovsk | N/A |\n| Two bridges across the Vovcha River | East of Starokasyanivske (west of Oleksandrivka) | Roughly 20 km from the frontline |\n\n## Innovation & Adaptation\n\n*   **Drones:** **Deep, Sustained Infrastructure Strikes.** Ukrainian forces are utilizing drones for sustained, high-impact strikes against deep rear targets, specifically focusing on critical energy infrastructure (e.g., oil refineries in Krasnodar and Perm krais) and military airfields (e.g., Shagol Airfield), degrading the enemy's industrial and logistical capacity far from the frontline.\n*   **EW (Electronic Warfare):** **Targeting of C2 and Sensor Assets.** Ukrainian forces are systematically targeting Russian electronic warfare and command-and-control infrastructure. This includes striking specific radar systems (e.g., Nebo-M radar) and drone storage/operational facilities, aiming to degrade the enemy's ability to detect and respond to attacks.\n*   **Tactics:** **Fully Unmanned Combined Arms Operations.** There is a marked tactical shift toward eliminating human involvement in direct combat. Forces are coordinating attacks using solely unmanned assets (UAVs and UGVs) to conduct complex, lethal operations (e.g., eliminating personnel in Kupyansk), minimizing risk while maintaining high operational tempo.	2026-05-02 18:04:47.367439	Local Gemma
88	\N	THEATER_MIDDLE_EAST	# MIDDLE_EAST THEATER REPORT\n\n## Tactical Momentum\nThe geopolitical landscape remains highly volatile, characterized by escalating tensions in critical maritime chokepoints and persistent diplomatic impasses. Specifically, the relationship between Iran and Western powers remains strained, with key regional players, including the UAE, openly expressing deep distrust regarding Iran's reliability in facilitating stability in the Strait of Hormuz. While there have been reports of Iran softening its public stance and engaging in discussions regarding peace plans with the US, these efforts are viewed through a lens of skepticism, suggesting that underlying strategic disagreements—particularly concerning regional influence and security guarantees—have not been resolved. Concurrently, Iran's domestic focus is marked by internal political shifts and economic maneuvering, including attention paid to cryptocurrency markets and the restructuring of its leadership, which adds layers of complexity to its external policy calculus.\n\nA separate, but equally critical, flashpoint is the escalating conflict dynamics along the Israel-Lebanon border. The operational tempo has been defined by a rapid technological escalation, with the deployment of sophisticated FPV drones and advanced fiber-optic surveillance systems redefining the nature of the conflict. While temporary truces have been observed, the underlying military momentum suggests a continuous cycle of technological counter-escalation. Furthermore, the international financial dimension of the conflict remains active, with major powers continuing to enforce stringent sanctions, including the freezing of assets and restrictions on financial transactions, thereby maintaining a high degree of economic pressure on the involved parties and complicating any path toward de-escalation.\n\n## Kinetic Impact\n\n| Target | Location | Distance |\n| :--- | :--- | :--- |\n| No specific kinetic strike data (Target, Location, Distance) was found in the provided source material. The sources discuss conflict and drone activity (e.g., Hezbollah-Israel FPV drones), but do not provide quantifiable strike data. | N/A | N/A |\n\n## Innovation & Adaptation\n\n*   **Drones (FPV/Mini-drones):** The widespread deployment of First-Person View (FPV) and mini-drones in conflict zones (e.g., Hezbollah-Israel, Ukraine). These systems are used for precision strikes, reconnaissance, and saturation attacks, fundamentally changing the cost and accessibility of battlefield weaponry.\n*   **Electronic Warfare (EW):** The integration of advanced electronic warfare capabilities, which are used to jam, disrupt, or blind enemy communications and sensor systems. This technology is crucial for neutralizing modern battlefield assets and protecting friendly forces.\n*   **Tactics (Networked Warfare):** The shift toward networked, combined-arms tactics that integrate drones, EW systems, and other technologies. This allows for real-time intelligence gathering and coordinated, multi-layered attacks that redefine the operational tempo and lethality of modern conflicts.	2026-05-02 18:05:47.832309	Local Gemma
61	\N	WORLD_NEWS	## Geopolitical Stability Report: Shifting Power Dynamics and International Friction Points\n\nThe geopolitical landscape is characterized by escalating friction within established alliances and a profound challenge to international legal norms, primarily centered on the Middle East. US-European military cooperation is showing signs of strain, evidenced by the planned withdrawal of 5,000 US troops from Germany. This reduction in force is directly linked to political discord between US leadership and key European allies, suggesting that national political disputes are undermining collective security commitments within NATO. The withdrawal signals a potential erosion of the unified front required to manage regional crises, forcing allies to reassess the reliability of US military guarantees.\n\nThe conflict in the Middle East remains the most volatile flashpoint, marked by continued fighting in Southern Lebanon despite ceasefire efforts, resulting in significant civilian casualties. This regional instability is compounded by severe economic risks, including potential fertilizer shortages that threaten global crop yields and the continued closure of critical shipping channels like the Strait of Hormuz, which poses systemic economic risks worldwide. Furthermore, the conflict is escalating into a legal and constitutional crisis regarding international law. US political rhetoric, specifically regarding the War Powers Act, challenges established legislative requirements for military action, arguing that a temporary ceasefire nullifies the need for Congressional authorization. This disregard for established law introduces extreme unpredictability into US foreign policy and military engagement.\n\nMacro-stability is further threatened by the confluence of these factors: the weakening of transatlantic alliances, the persistent violence in the Levant, and the disregard for international legal frameworks. The combination of these elements suggests a period of heightened strategic uncertainty. The inability of major powers to maintain consensus on military intervention, coupled with the localized, high-intensity conflict involving state and non-state actors, increases the risk of miscalculation and unintended escalation. Monitoring the adherence to international law and the cohesion of allied military planning will be critical indicators of global stability in the coming cycle.	2026-05-02 12:36:49.069719	\N
62	\N	US_NEWS	### Domestic Policy Briefing: Internal Strategic Landscape Assessment\n\nThe internal strategic landscape is characterized by significant legislative friction and escalating social polarization, compounded by economic uncertainty. The ongoing constitutional debate surrounding the Iran conflict represents a critical domestic challenge, as the administration's defiance of the 1973 War Powers Resolution creates profound institutional instability. By arguing that a ceasefire nullifies the requirement for Congressional authorization, the executive branch is directly challenging established legislative checks and balances. This defiance has fueled intense political debate, with legal experts questioning the administration's interpretation of the statute, suggesting that a mere pause in hostilities does not legally terminate the clock on Congressional action.\n\nEconomically, the nation faces mounting pressure from global instability and domestic market shifts. The continued closure of the Strait of Hormuz, coupled with rising energy prices, is creating inflationary pressures and impacting consumer stability, as evidenced by public reactions to gas costs. Furthermore, the collapse of bailout talks for carriers like Spirit Airlines signals a tightening financial environment and increased vulnerability within key domestic industries. These economic headwinds are occurring against a backdrop of heightened social activism, exemplified by large-scale May Day protests demanding justice for workers and immigrants, indicating deep-seated dissatisfaction with current economic and social policies.\n\nOn the domestic legal front, the restriction of access to mifepristone via court ruling represents a significant legislative and social policy shift, directly impacting reproductive healthcare access and fueling further political division. Simultaneously, the rapid integration of Artificial Intelligence into the military, as seen in the Pentagon's 'AI-first' contracts, signals a major, resource-intensive shift in defense spending and technological focus. This technological pivot, combined with the political fallout from incidents like the shooting at the press dinner, underscores a domestic environment where institutional trust is fragile, and political conflict is increasingly manifesting in both the legislative chambers and the public sphere.	2026-05-02 12:37:14.443412	\N
63	\N	FINANCE	## MACRO ASSESSMENT: MARKET HEALTH AND SYSTEMIC RISK\n\nMarket volatility remains elevated, driven by a bifurcated set of forces: robust corporate earnings from select technology sectors juxtaposed against persistent geopolitical and inflationary headwinds. While positive earnings reports provide temporary upward momentum, the underlying market structure is highly sensitive to geopolitical de-escalation, as evidenced by the market's reaction to the US-Iran ceasefire. Inflationary pressures, which have reached multi-year highs, continue to keep interest rate expectations in sharp focus, suggesting that the Federal Reserve's policy path remains highly contingent on inflation data and global stability. This dichotomy suggests that market resilience is currently concentrated in specific, high-growth sectors, while broader market health remains susceptible to sudden shifts in global risk sentiment.\n\nSystemic financial risk is being amplified by escalating trade protectionism and institutional unpredictability. The aggressive tariff escalation targeting the European Union's automotive sector signals a rapid deterioration of transatlantic trade relations, moving away from multilateral agreements toward unilateral, punitive measures. This trend of escalating trade friction introduces significant supply chain risk and raises the cost of capital for multinational corporations. Furthermore, sector-specific stress, such as the operational collapse observed in the airline industry due to soaring jet fuel costs exacerbated by conflict, demonstrates how geopolitical shocks can quickly translate into acute, localized financial distress, threatening solvency even among historically robust industries.\n\nFiscal policy stability is severely compromised by the current political climate, manifesting as a return to aggressive, non-negotiable trade barriers. The willingness to unilaterally impose tariffs, even on established partners, undermines the predictability required for long-term capital investment and global commerce. This policy environment suggests a shift toward economic nationalism, where trade agreements are viewed less as mechanisms for mutual benefit and more as tools for immediate political leverage. The combination of unpredictable trade policy, persistent inflationary pressures, and geopolitical instability creates a high-risk macro environment, suggesting that systemic risk is not merely cyclical, but structural, rooted in the erosion of established international economic norms.	2026-05-02 12:37:38.132571	\N
64	\N	TECHNOLOGY	The current landscape reveals a bifurcation between rapidly advancing, yet fragile, AI capabilities and the hardening of physical, process-based technical moats. AI advancement is characterized by both sophisticated capability and immediate monetization control points. The emergence of models like Grok 4.3 and the observed resource allocation shifts (e.g., Uber cutting AI budgets) indicate market volatility, while the technical integration of AI into core infrastructure—such as the discovery of malware within the PyTorch Lightning training library—highlights critical supply chain vulnerabilities. Furthermore, the industry is rapidly developing mechanisms for content provenance, exemplified by Spotify's 'Verified' badges, which signals a defensive shift toward verifying human-generated content against synthetic media.\n\nInfrastructure robustness is being tested by both geopolitical and engineering extremes. The decision by Belgium to halt nuclear decommissioning signals a strategic pivot toward maintaining stable, high-density power sources, mitigating the risk of energy grid fragmentation. On the manufacturing side, the complexity of high-precision polymer engineering, particularly the use of advanced materials like Sterrox® LCP, establishes profound physical moats. The difficulty in introducing color pigments (like carbon black) into injection molding, which necessitates extensive, costly, and time-consuming re-tooling and validation cycles, demonstrates that physical manufacturing processes can create delays and barriers to entry far exceeding software development timelines.\n\nThe most potent technical moats are increasingly centered on data capture and systemic control. Privacy concerns are escalating, with reports detailing pervasive data collection across vehicles (Rivian) and browser extensions (LinkedIn), indicating a systemic shift toward mandatory data telemetry. Security vulnerabilities are also becoming more deeply embedded; the lack of proactive heads-up for Linux kernel vulnerabilities and the discovery of sophisticated malware in popular AI libraries underscore the fragility of open-source dependencies. Finally, the consolidation of information services, evidenced by the closure of Ask.com, confirms the market's retreat toward centralized, proprietary search and data aggregation platforms, reinforcing the power of established gatekeepers.	2026-05-02 12:38:08.76057	\N
65	\N	THEATER_UKRAINE	# UKRAINE THEATER REPORT\n\nUkrainian forces have maintained a sustained and aggressive deep-strike campaign against Russian strategic assets, significantly degrading key economic and military infrastructure across multiple regions. Strikes have repeatedly targeted major oil refining facilities, including those in Krasnodar, Perm, and Orenburg Oblasts, causing substantial damage, operational suspensions, and multiple fires. Concurrently, the campaign has extended deep into Russian territory, hitting military installations such as airfields hundreds of kilometers from the international border, and striking radar and drone storage facilities near the front lines in Belgorod Oblast. These deep operations, coupled with ongoing strikes against Russian artillery command posts and ammunition depots in occupied territories, have severely disrupted Russian logistics and reduced the average output of Russian oil refineries to levels not seen since late 2009.\n\nOn the frontline, ground activity remains highly localized, with neither side achieving confirmed advances. Russian forces continue to conduct persistent infiltration missions, particularly utilizing pipelines in the Sumy and Kupyansk directions, and attempting to penetrate Ukrainian defenses in the Slovyansk and Donetsk sectors. In response, Ukrainian forces are actively countering these incursions. While Russian forces continue to apply pressure, the nature of the fighting suggests a shift toward localized attrition. Furthermore, the conflict remains characterized by intense, small-scale engagements, with both sides engaging in continuous efforts to secure tactical advantages, while the strategic focus remains on disrupting enemy supply lines and maintaining operational depth.\n\n## Major Strikes and Targets\n\n| Target | Location | Estimated Distance from Front Lines |\n| :--- | :--- | :--- |\n| **Aircraft/Military Assets** | Near the front lines (General) | Varies |\n| **Drone/Air Assets** | Near the front lines (General) | Varies |\n| **Infrastructure/Industrial Targets** | Various locations (General) | Varies |\n\n***\n\n## Specific Strikes and Strikes on Infrastructure\n\n| Target | Location | Estimated Distance from Front Lines |\n| :--- | :--- | :--- |\n| **Oil/Gas Infrastructure** | Various locations (General) | Varies |\n| **Rail/Transportation Hubs** | Various locations (General) | Varies |\n| **Radar/Communication Sites** | Various locations (General) | Varies |\n\n***\n\n## Strikes on Key Military/Strategic Assets\n\n| Target | Location | Estimated Distance from Front Lines |\n| :--- | :--- | :--- |\n| **Artillery/Military Concentrations** | Various locations (General) | Varies |\n| **Command and Control Centers** | Various locations (General) | Varies |\n| **Airfields/Airstrips** | Various locations (General) | Varies |\n\n***\n\n## Strikes on Specific Locations (As Reported)\n\n| Target | Location | Estimated Distance from Front Lines |\n| :--- | :--- | :--- |\n| **Military/Industrial Targets** | **Kakhovka Dam Area** | Varies |\n| **Military/Industrial Targets** | **Crimean Peninsula** | Varies |\n| **Military/Industrial Targets** | **Donetsk/Luhansk Regions** | Varies |\n| **Military/Industrial Targets** | **Zaporizhzhia Region** | Varies |\n\n***\n\n**Note:** *The provided text is a general summary of potential targets and strike areas. Specific, real-time targeting data is highly classified and constantly changing. The table above is structured to categorize the types of targets typically struck by advanced military forces.*\n\n## Innovation & Adaptation\n\n*   **Unmanned Systems Warfare (USF):** The increasing reliance on unmanned systems for both offensive and defensive operations. This is evidenced by the reports of coordinated, multi-platform attacks (e.g., targeting air defenses and infrastructure) and the use of drones in ground combat, exemplified by the mention of unmanned systems in the context of the war.\n*   **Deep Strike Capability:** The ability to conduct sustained, high-impact strikes far behind the front lines, targeting critical economic and military infrastructure. This is demonstrated by the repeated targeting of major oil refining facilities and industrial complexes deep within enemy territory.\n*   **Advanced Counter-ISR/EW:** The integration of electronic warfare (EW) and intelligence, surveillance, and reconnaissance (ISR) capabilities to degrade enemy command and control (C2) networks. This includes the use of sophisticated jamming and radar systems to blind or confuse enemy air defenses and communication nodes.	2026-05-02 12:39:16.219644	\N
66	\N	THEATER_MIDDLE_EAST	# MIDDLE_EAST THEATER REPORT\n\nThe geopolitical landscape remains highly volatile, centered on the Persian Gulf and the strategic importance of the Strait of Hormuz. While there are indications that Iran is attempting to soften its public stance and engage in peace discussions with the United States, regional partners maintain deep skepticism regarding Tehran's commitment to stability. Major Gulf states have publicly questioned Iran's reliability in guaranteeing maritime security, suggesting that the path toward de-escalation remains fraught with significant diplomatic and operational impasses. Concurrently, the United States and its allies are actively pursuing dialogue concerning nuclear and maritime security protocols, while the Iranian leadership itself faces scrutiny regarding the clarity and continuity of its post-conflict strategic planning.\n\nSecondary conflict theaters are defined by rapid technological escalation and complex political constraints. The confrontation between Hezbollah and Israel is characterized by the sophisticated deployment of asymmetric weaponry, particularly FPV drones and advanced fiber-optic systems, which are redefining the nature of ground combat. However, the operational tempo in this region is currently moderated by existing truces, which limit the scope of overt military action. Furthermore, the global economic dimension of the conflict is being aggressively managed through financial warfare; the United States continues to utilize advanced sanctions, including the freezing of cryptocurrency assets and targeting major financial infrastructure, to exert pressure on key state and non-state actors.\n\nBased on the provided URLs, the content focuses heavily on geopolitical analysis, diplomatic tensions, sanctions, and general conflict reporting (e.g., drone threats, political statements). None of the links contain specific, actionable data detailing a kinetic strike with a defined Target, Location, and Border Distance.\n\nTherefore, I cannot generate the requested table.\n\n## Innovation & Adaptation\n\n*   **Drones (FPV Systems):** The widespread deployment of inexpensive, highly maneuverable First-Person View (FPV) drones has redefined battlefield engagement. These systems allow non-state actors and militaries to achieve high levels of lethality and tactical surprise against armored vehicles and fixed positions, as demonstrated in the Israel-Hezbollah conflict.\n*   **Electronic Warfare (EW):** Modern conflict increasingly relies on EW capabilities to disrupt enemy communications, targeting systems, and command structures. This includes jamming and spoofing technologies that degrade the enemy's ability to coordinate and operate advanced weaponry, making electronic superiority a critical battlefield objective.\n*   **Tactics (Networked/Fiber-Optic Integration):** Battlefield tactics are adapting to integrate advanced communication and targeting methods. The use of fiber-optic technology, combined with drone platforms, allows for real-time, high-bandwidth data transmission and precise targeting, enabling a shift toward highly networked and decentralized combat operations.	2026-05-02 12:40:02.956122	\N
67	\N	GLOBAL_SITREP	# Global Conflict Landscape Strategic Overview (SITREP)\n\nThe global conflict landscape remains characterized by a strategic stalemate on the frontline, offset by a significant escalation in the deep rear and economic warfare conducted by Ukrainian forces. The conflict has transitioned into a multi-domain attrition war, where the primary objective for both sides appears to be degrading the opponent's capacity to sustain operations, rather than achieving rapid territorial gains. Ukrainian strikes against Russian energy infrastructure—including multiple hits on major refineries in Krasnodar, Perm, and Orenburg—have degraded average Russian oil output to levels not seen since late 2009, signaling a successful strategic campaign aimed at crippling Russia's economic war machine. Concurrently, the frontlines remain locked in a cycle of limited, localized advances and deep infiltration attempts, with neither side achieving a decisive breakthrough.\n\nMomentum is currently bifurcated across theaters. In the strategic rear, momentum heavily favors Ukraine. The sustained, sophisticated drone and missile campaign targeting critical energy assets, airfields (e.g., Shagol Airfield), and military infrastructure hundreds of kilometers behind the front lines demonstrates a high operational tempo and increasing capability. This campaign is not merely punitive; it directly impacts Russia's industrial and logistical capacity. Conversely, on the ground, momentum is highly contested and localized. While Russian forces continue to employ infiltration missions and maintain pressure across multiple axes (Kharkiv, Donetsk), their advances are consistently limited, often failing to translate into sustained territorial control.\n\nOn the frontline, the fighting is characterized by intense, low-intensity attrition. In the Kharkiv and Donetsk sectors, Russian forces continue to utilize pipelines for small-group infiltration missions, attempting to create defensible buffer zones. However, these efforts are being countered by coordinated Ukrainian counterattacks and persistent mid-range strikes against Russian command posts and ammunition depots. The fighting in the Donetsk Oblast, particularly around Slovyansk and Kramatorsk, shows a tactical shift: while Russian forces maintain high artillery and drone strike activity, their ground assaults are reportedly decreasing in size and intensity, suggesting a struggle to overcome dense Ukrainian air defenses.\n\nOverall, the strategic picture suggests a protracted war of attrition where the economic and logistical front is the most volatile theater. Ukraine's ability to project power deep into Russia's rear is the primary force driving strategic change, forcing Russia to dedicate significant resources to defense and repair. Meanwhile, the ground war remains a grinding struggle of maneuver and counter-maneuver, with the operational focus shifting from large-scale offensives to small-unit, high-intensity engagements aimed at attrition and maintaining localized pressure.	2026-05-02 12:40:41.119285	\N
\.


--
-- Data for Name: llm_configs; Type: TABLE DATA; Schema: public; Owner: huduser
--

COPY public.llm_configs (id, active, api_key, base_url, model_name, name, num_ctx, provider, updated_at) FROM stdin;
1	t	\N	http://inference.jakefear.com:11434	gemma4:e4b	Local Gemma	65536	OLLAMA	2026-05-02 14:31:53.898064
\.


--
-- Data for Name: pipeline_runs; Type: TABLE DATA; Schema: public; Owner: huduser
--

COPY public.pipeline_runs (id, category, end_time, error_message, start_time, status, model_name) FROM stdin;
36	WORLD_NEWS	2026-05-02 12:22:59.742179	\N	2026-05-02 12:22:33.394212	SUCCESS	\N
37	US_NEWS	2026-05-02 12:23:26.525816	\N	2026-05-02 12:22:59.75117	SUCCESS	\N
38	FINANCE	2026-05-02 12:23:52.12003	\N	2026-05-02 12:23:26.528547	SUCCESS	\N
39	TECHNOLOGY	2026-05-02 12:24:23.480773	\N	2026-05-02 12:23:52.122274	SUCCESS	\N
40	THEATER_UKRAINE	2026-05-02 12:24:46.063613	\N	2026-05-02 12:24:23.482202	SUCCESS	\N
41	THEATER_MIDDLE_EAST	2026-05-02 12:24:47.074965	No deep-dive sources found for THEATER_MIDDLE_EAST	2026-05-02 12:24:46.06581	FAILED	\N
42	GLOBAL_SITREP	2026-05-02 12:25:04.051141	\N	2026-05-02 12:24:47.079914	SUCCESS	\N
43	WORLD_NEWS	2026-05-02 12:27:55.993562	\N	2026-05-02 12:27:31.581613	SUCCESS	\N
44	US_NEWS	2026-05-02 12:28:22.217316	\N	2026-05-02 12:27:56.001305	SUCCESS	\N
45	FINANCE	2026-05-02 12:28:53.52601	\N	2026-05-02 12:28:22.219518	SUCCESS	\N
46	TECHNOLOGY	2026-05-02 12:29:23.031569	\N	2026-05-02 12:28:53.528079	SUCCESS	\N
47	THEATER_UKRAINE	2026-05-02 12:29:46.952866	\N	2026-05-02 12:29:23.033564	SUCCESS	\N
48	THEATER_MIDDLE_EAST	2026-05-02 12:29:48.622438	No deep-dive sources found for THEATER_MIDDLE_EAST	2026-05-02 12:29:46.955865	FAILED	\N
49	GLOBAL_SITREP	2026-05-02 12:30:05.466509	\N	2026-05-02 12:29:48.625093	SUCCESS	\N
50	WORLD_NEWS	2026-05-02 12:34:12.784429	No EntityManager with actual transaction available for current thread - cannot reliably process 'remove' call	2026-05-02 12:33:12.842201	FAILED	\N
51	US_NEWS	2026-05-02 12:34:38.344353	No EntityManager with actual transaction available for current thread - cannot reliably process 'remove' call	2026-05-02 12:34:12.79355	FAILED	\N
52	FINANCE	2026-05-02 12:35:01.963362	No EntityManager with actual transaction available for current thread - cannot reliably process 'remove' call	2026-05-02 12:34:38.349101	FAILED	\N
53	TECHNOLOGY	2026-05-02 12:35:32.175222	No EntityManager with actual transaction available for current thread - cannot reliably process 'remove' call	2026-05-02 12:35:01.970308	FAILED	\N
54	THEATER_UKRAINE	\N	\N	2026-05-02 12:35:32.181092	PENDING	\N
55	WORLD_NEWS	2026-05-02 12:36:49.077528	\N	2026-05-02 12:36:24.03273	SUCCESS	\N
56	US_NEWS	2026-05-02 12:37:14.449403	\N	2026-05-02 12:36:49.088141	SUCCESS	\N
57	FINANCE	2026-05-02 12:37:38.135021	\N	2026-05-02 12:37:14.451978	SUCCESS	\N
58	TECHNOLOGY	2026-05-02 12:38:08.76387	\N	2026-05-02 12:37:38.140977	SUCCESS	\N
26	FINANCE	\N	\N	2026-05-02 12:13:47.463917	PENDING	\N
27	WORLD_NEWS	2026-05-02 12:16:17.689615	\N	2026-05-02 12:14:15.703594	SUCCESS	\N
28	US_NEWS	\N	\N	2026-05-02 12:16:17.698428	PENDING	\N
29	WORLD_NEWS	2026-05-02 12:17:52.794163	\N	2026-05-02 12:17:31.387391	SUCCESS	\N
30	US_NEWS	2026-05-02 12:18:15.055699	\N	2026-05-02 12:17:52.800253	SUCCESS	\N
31	FINANCE	2026-05-02 12:18:37.509658	\N	2026-05-02 12:18:15.058484	SUCCESS	\N
32	TECHNOLOGY	2026-05-02 12:19:02.27393	\N	2026-05-02 12:18:37.512072	SUCCESS	\N
33	THEATER_UKRAINE	2026-05-02 12:19:23.929175	\N	2026-05-02 12:19:02.276388	SUCCESS	\N
34	THEATER_MIDDLE_EAST	2026-05-02 12:19:25.001972	No deep-dive sources found for THEATER_MIDDLE_EAST	2026-05-02 12:19:23.931223	FAILED	\N
35	GLOBAL_SITREP	2026-05-02 12:19:40.757392	\N	2026-05-02 12:19:25.004568	SUCCESS	\N
59	THEATER_UKRAINE	2026-05-02 12:39:16.222379	\N	2026-05-02 12:38:08.77084	SUCCESS	\N
60	THEATER_MIDDLE_EAST	2026-05-02 12:40:03.027573	\N	2026-05-02 12:39:16.228659	SUCCESS	\N
61	GLOBAL_SITREP	2026-05-02 12:40:41.121667	\N	2026-05-02 12:40:03.031047	SUCCESS	\N
62	WORLD_NEWS	2026-05-02 14:32:29.032735	\N	2026-05-02 14:32:00.860644	SUCCESS	Local Gemma
63	US_NEWS	2026-05-02 14:32:54.477967	\N	2026-05-02 14:32:29.04579	SUCCESS	Local Gemma
64	FINANCE	2026-05-02 14:33:16.225526	\N	2026-05-02 14:32:54.482652	SUCCESS	Local Gemma
65	TECHNOLOGY	2026-05-02 14:33:46.238317	\N	2026-05-02 14:33:16.23122	SUCCESS	Local Gemma
66	THEATER_UKRAINE	2026-05-02 14:34:45.539773	\N	2026-05-02 14:33:46.240902	SUCCESS	Local Gemma
67	THEATER_MIDDLE_EAST	2026-05-02 14:35:25.116008	\N	2026-05-02 14:34:45.548516	SUCCESS	Local Gemma
68	GLOBAL_SITREP	2026-05-02 14:35:53.031887	\N	2026-05-02 14:35:25.119433	SUCCESS	Local Gemma
69	WORLD_NEWS	2026-05-02 14:58:43.788571	\N	2026-05-02 14:58:20.380554	SUCCESS	Local Gemma
70	US_NEWS	2026-05-02 14:59:10.439933	\N	2026-05-02 14:58:43.80053	SUCCESS	Local Gemma
71	FINANCE	2026-05-02 14:59:33.577733	\N	2026-05-02 14:59:10.443576	SUCCESS	Local Gemma
72	TECHNOLOGY	2026-05-02 15:00:02.480331	\N	2026-05-02 14:59:33.584157	SUCCESS	Local Gemma
73	GLOBAL_SITREP	2026-05-02 15:00:36.116229	\N	2026-05-02 15:00:02.486489	SUCCESS	Local Gemma
74	THEATER_UKRAINE	2026-05-02 15:01:31.117808	\N	2026-05-02 15:00:36.12338	SUCCESS	Local Gemma
75	THEATER_MIDDLE_EAST	2026-05-02 15:02:10.686579	\N	2026-05-02 15:01:31.124247	SUCCESS	Local Gemma
76	WORLD_NEWS	2026-05-02 18:01:51.844914	\N	2026-05-02 18:01:22.630934	SUCCESS	Local Gemma
77	US_NEWS	2026-05-02 18:02:14.278273	\N	2026-05-02 18:01:51.854925	SUCCESS	Local Gemma
78	FINANCE	2026-05-02 18:02:37.820989	\N	2026-05-02 18:02:14.281968	SUCCESS	Local Gemma
79	TECHNOLOGY	2026-05-02 18:03:03.67284	\N	2026-05-02 18:02:37.826923	SUCCESS	Local Gemma
80	GLOBAL_SITREP	2026-05-02 18:03:36.031161	\N	2026-05-02 18:03:03.675204	SUCCESS	Local Gemma
81	THEATER_UKRAINE	2026-05-02 18:04:47.370368	\N	2026-05-02 18:03:36.036497	SUCCESS	Local Gemma
82	THEATER_MIDDLE_EAST	2026-05-02 18:05:47.835406	\N	2026-05-02 18:04:47.373072	SUCCESS	Local Gemma
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: huduser
--

COPY public.users (id, password, role, username) FROM stdin;
1	$2a$10$Rr6fgqXVNwdeJfzE4iSRHuMkNlr1.iI5siajO.wd726rS7D6rHEai	ROLE_ADMIN	admin
\.


--
-- Name: daily_briefings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: huduser
--

SELECT pg_catalog.setval('public.daily_briefings_id_seq', 88, true);


--
-- Name: llm_configs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: huduser
--

SELECT pg_catalog.setval('public.llm_configs_id_seq', 1, true);


--
-- Name: pipeline_runs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: huduser
--

SELECT pg_catalog.setval('public.pipeline_runs_id_seq', 82, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: huduser
--

SELECT pg_catalog.setval('public.users_id_seq', 1, true);


--
-- Name: daily_briefings daily_briefings_pkey; Type: CONSTRAINT; Schema: public; Owner: huduser
--

ALTER TABLE ONLY public.daily_briefings
    ADD CONSTRAINT daily_briefings_pkey PRIMARY KEY (id);


--
-- Name: llm_configs llm_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: huduser
--

ALTER TABLE ONLY public.llm_configs
    ADD CONSTRAINT llm_configs_pkey PRIMARY KEY (id);


--
-- Name: pipeline_runs pipeline_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: huduser
--

ALTER TABLE ONLY public.pipeline_runs
    ADD CONSTRAINT pipeline_runs_pkey PRIMARY KEY (id);


--
-- Name: llm_configs uk_a6k7d65a7xbm777jrw21ov0ju; Type: CONSTRAINT; Schema: public; Owner: huduser
--

ALTER TABLE ONLY public.llm_configs
    ADD CONSTRAINT uk_a6k7d65a7xbm777jrw21ov0ju UNIQUE (name);


--
-- Name: users uk_r43af9ap4edm43mmtq01oddj6; Type: CONSTRAINT; Schema: public; Owner: huduser
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT uk_r43af9ap4edm43mmtq01oddj6 UNIQUE (username);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: huduser
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

\unrestrict AMA7TUtDhRz07cB3cYlRIenJVXOaYdhpA3ahR5K5bXJeqiSdeLdJIAYp3A9SWbo

